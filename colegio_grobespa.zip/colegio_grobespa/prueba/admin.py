# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from prueba.models import Prueba
from prueba.models import Estado
# Register your models here.
admin.site.register(Prueba)
admin.site.register(Estado)

# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from curso.models import Curso
from alumno.models import Alumno
from django.core.validators import MinValueValidator
from django.core.validators import MaxValueValidator
# Create your models here.
class Prueba(models.Model):
    class Meta:
        verbose_name_plural="Pruebas"
    Curso_prueba=models.ForeignKey(Curso, verbose_name="Curso")
    Nombre_prueba=models.CharField(max_length=50, null=True,
                                          verbose_name="Nombre")
    Alumno_prueba=models.ForeignKey(Alumno, null=True,
                                          verbose_name="Alumno")
    Calificacion=models.IntegerField(validators=[MinValueValidator(0), MaxValueValidator(20)],  blank=False, null=True, verbose_name="Calificación")
    Estado=models.ForeignKey('Estado', null=True)

    def __str__(self):
        return '%s %s' % (self.Alumno_prueba, self.Nombre_prueba)
    def __unicode__(self):
        return '%s %s' % (self.Alumno_prueba, self.Nombre_prueba)

class Estado(models.Model):
    class Meta:
        verbose_name_plural = "Estados"
    Nombre=models.CharField(max_length=20, null=True)
    Nombre2=models.CharField(max_length=20, null=True)

    def __str__(self):
        return '%s' % (self.Nombre)
    def __unicode__(self):
        return '%s' % (self.Nombre)


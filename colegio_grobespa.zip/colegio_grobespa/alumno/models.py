# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here.
class Alumno(models.Model):
    class Meta:
        verbose_name_plural = "Alumnos"
    Nombre=models.CharField(max_length=25, blank=False,
                                         null=False, verbose_name="Nombre")
    Apellido=models.CharField(max_length=30, blank=False,
                                         null=False, verbose_name="Apellido")
    Edad=models.IntegerField(blank=False, null=False, 
                                          verbose_name="Edad")
    Cedula=models.IntegerField(blank=False, null=False,
                                          verbose_name="Cedula")
    Num_tlf=models.CharField(max_length=12, blank=False, null=False,
                                           verbose_name="Numero de Telefono")
    Correo=models.EmailField(blank=False, null=False,
                                         verbose_name="Correo Electronico")
    Comentarios=models.TextField(max_length=100, blank=True)

    def __str__(self):
        return '%s %s %s' % (self.Nombre, self.Apellido, self.Cedula)
    def __unicode__(self):
        return '%s %s %s' % (self.Nombre, self.Apellido, self.Cedula)

# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from alumno.models import Alumno
# Register your models here.
admin.site.register(Alumno)

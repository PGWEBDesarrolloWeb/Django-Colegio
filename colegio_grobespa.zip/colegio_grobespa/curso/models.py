# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from profesor.models  import Profesor
from especialidad.models import Especialidad
from alumno.models import Alumno
# Create your models here.
class Curso(models.Model):
    class Meta:
        verbose_name_plural= "Cursos"
    Especialidad=models.ForeignKey(Especialidad, null=True)
    Nombre=models.CharField(max_length=40, blank=False,
                                         null=False, verbose_name="Nombre")
    Codigo=models.IntegerField(blank=False, null=True, unique=True,
                                          verbose_name="Codigo")
    Duracion=models.IntegerField(blank=False, null=False, 
                                            verbose_name="Duracion del curso(Meses)")
    Profesor=models.ForeignKey(Profesor,null=True)
    Fecha_inicio=models.DateField(("Fecha de inicio"), blank=False, null=True)
    Hora_Comienzo=models.TimeField(("Hora inicio de clases"), blank=False, null=True)
    Hora_Fin=models.TimeField(("Hora de final de clases"), blank=False, null=True)
    Alumnos_inscritos=models.ManyToManyField(Alumno, blank=False)
    def __str__(self):
        return '%s' % (self.Nombre)
    def __unicode__(self):
        return '%s' % (self.Nombre)

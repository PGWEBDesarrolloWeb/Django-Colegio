--
-- PostgreSQL database dump
--

-- Dumped from database version 9.4.15
-- Dumped by pg_dump version 9.4.15
-- Started on 2018-03-05 13:15:41 VET

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- TOC entry 1 (class 3079 OID 11861)
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- TOC entry 2244 (class 0 OID 0)
-- Dependencies: 1
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 192 (class 1259 OID 25541)
-- Name: alumno_alumno; Type: TABLE; Schema: public; Owner: pedro; Tablespace: 
--

CREATE TABLE alumno_alumno (
    id integer NOT NULL,
    "Nombre" character varying(25) NOT NULL,
    "Apellido" character varying(30) NOT NULL,
    "Edad" integer NOT NULL,
    "Cedula" integer NOT NULL,
    "Num_tlf" character varying(12) NOT NULL,
    "Correo" character varying(254) NOT NULL,
    "Comentarios" text NOT NULL
);


ALTER TABLE alumno_alumno OWNER TO pedro;

--
-- TOC entry 191 (class 1259 OID 25539)
-- Name: alumno_alumno_id_seq; Type: SEQUENCE; Schema: public; Owner: pedro
--

CREATE SEQUENCE alumno_alumno_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE alumno_alumno_id_seq OWNER TO pedro;

--
-- TOC entry 2245 (class 0 OID 0)
-- Dependencies: 191
-- Name: alumno_alumno_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pedro
--

ALTER SEQUENCE alumno_alumno_id_seq OWNED BY alumno_alumno.id;


--
-- TOC entry 180 (class 1259 OID 25420)
-- Name: auth_group; Type: TABLE; Schema: public; Owner: pedro; Tablespace: 
--

CREATE TABLE auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE auth_group OWNER TO pedro;

--
-- TOC entry 179 (class 1259 OID 25418)
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: pedro
--

CREATE SEQUENCE auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_group_id_seq OWNER TO pedro;

--
-- TOC entry 2246 (class 0 OID 0)
-- Dependencies: 179
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pedro
--

ALTER SEQUENCE auth_group_id_seq OWNED BY auth_group.id;


--
-- TOC entry 182 (class 1259 OID 25430)
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: pedro; Tablespace: 
--

CREATE TABLE auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE auth_group_permissions OWNER TO pedro;

--
-- TOC entry 181 (class 1259 OID 25428)
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: pedro
--

CREATE SEQUENCE auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_group_permissions_id_seq OWNER TO pedro;

--
-- TOC entry 2247 (class 0 OID 0)
-- Dependencies: 181
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pedro
--

ALTER SEQUENCE auth_group_permissions_id_seq OWNED BY auth_group_permissions.id;


--
-- TOC entry 178 (class 1259 OID 25412)
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: pedro; Tablespace: 
--

CREATE TABLE auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE auth_permission OWNER TO pedro;

--
-- TOC entry 177 (class 1259 OID 25410)
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: pedro
--

CREATE SEQUENCE auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_permission_id_seq OWNER TO pedro;

--
-- TOC entry 2248 (class 0 OID 0)
-- Dependencies: 177
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pedro
--

ALTER SEQUENCE auth_permission_id_seq OWNED BY auth_permission.id;


--
-- TOC entry 184 (class 1259 OID 25438)
-- Name: auth_user; Type: TABLE; Schema: public; Owner: pedro; Tablespace: 
--

CREATE TABLE auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(30) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE auth_user OWNER TO pedro;

--
-- TOC entry 186 (class 1259 OID 25448)
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: pedro; Tablespace: 
--

CREATE TABLE auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE auth_user_groups OWNER TO pedro;

--
-- TOC entry 185 (class 1259 OID 25446)
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: pedro
--

CREATE SEQUENCE auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_user_groups_id_seq OWNER TO pedro;

--
-- TOC entry 2249 (class 0 OID 0)
-- Dependencies: 185
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pedro
--

ALTER SEQUENCE auth_user_groups_id_seq OWNED BY auth_user_groups.id;


--
-- TOC entry 183 (class 1259 OID 25436)
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: pedro
--

CREATE SEQUENCE auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_user_id_seq OWNER TO pedro;

--
-- TOC entry 2250 (class 0 OID 0)
-- Dependencies: 183
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pedro
--

ALTER SEQUENCE auth_user_id_seq OWNED BY auth_user.id;


--
-- TOC entry 188 (class 1259 OID 25456)
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: pedro; Tablespace: 
--

CREATE TABLE auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE auth_user_user_permissions OWNER TO pedro;

--
-- TOC entry 187 (class 1259 OID 25454)
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: pedro
--

CREATE SEQUENCE auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_user_user_permissions_id_seq OWNER TO pedro;

--
-- TOC entry 2251 (class 0 OID 0)
-- Dependencies: 187
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pedro
--

ALTER SEQUENCE auth_user_user_permissions_id_seq OWNED BY auth_user_user_permissions.id;


--
-- TOC entry 198 (class 1259 OID 25582)
-- Name: curso_curso; Type: TABLE; Schema: public; Owner: pedro; Tablespace: 
--

CREATE TABLE curso_curso (
    id integer NOT NULL,
    "Nombre" character varying(40) NOT NULL,
    "Duracion" integer NOT NULL,
    "Fecha_inicio" date,
    "Hora_Comienzo" time without time zone,
    "Hora_Fin" time without time zone,
    "Profesor_id" integer,
    "Especialidad_id" integer,
    "Codigo" integer
);


ALTER TABLE curso_curso OWNER TO pedro;

--
-- TOC entry 197 (class 1259 OID 25580)
-- Name: curso_cosecha_id_seq; Type: SEQUENCE; Schema: public; Owner: pedro
--

CREATE SEQUENCE curso_cosecha_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE curso_cosecha_id_seq OWNER TO pedro;

--
-- TOC entry 2252 (class 0 OID 0)
-- Dependencies: 197
-- Name: curso_cosecha_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pedro
--

ALTER SEQUENCE curso_cosecha_id_seq OWNED BY curso_curso.id;


--
-- TOC entry 200 (class 1259 OID 25606)
-- Name: curso_curso_Alumnos_inscritos; Type: TABLE; Schema: public; Owner: pedro; Tablespace: 
--

CREATE TABLE "curso_curso_Alumnos_inscritos" (
    id integer NOT NULL,
    curso_id integer NOT NULL,
    alumno_id integer NOT NULL
);


ALTER TABLE "curso_curso_Alumnos_inscritos" OWNER TO pedro;

--
-- TOC entry 199 (class 1259 OID 25604)
-- Name: curso_curso_Alumnos_inscritos_id_seq; Type: SEQUENCE; Schema: public; Owner: pedro
--

CREATE SEQUENCE "curso_curso_Alumnos_inscritos_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "curso_curso_Alumnos_inscritos_id_seq" OWNER TO pedro;

--
-- TOC entry 2253 (class 0 OID 0)
-- Dependencies: 199
-- Name: curso_curso_Alumnos_inscritos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pedro
--

ALTER SEQUENCE "curso_curso_Alumnos_inscritos_id_seq" OWNED BY "curso_curso_Alumnos_inscritos".id;


--
-- TOC entry 190 (class 1259 OID 25516)
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: pedro; Tablespace: 
--

CREATE TABLE django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE django_admin_log OWNER TO pedro;

--
-- TOC entry 189 (class 1259 OID 25514)
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: pedro
--

CREATE SEQUENCE django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_admin_log_id_seq OWNER TO pedro;

--
-- TOC entry 2254 (class 0 OID 0)
-- Dependencies: 189
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pedro
--

ALTER SEQUENCE django_admin_log_id_seq OWNED BY django_admin_log.id;


--
-- TOC entry 176 (class 1259 OID 25402)
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: pedro; Tablespace: 
--

CREATE TABLE django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE django_content_type OWNER TO pedro;

--
-- TOC entry 175 (class 1259 OID 25400)
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: pedro
--

CREATE SEQUENCE django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_content_type_id_seq OWNER TO pedro;

--
-- TOC entry 2255 (class 0 OID 0)
-- Dependencies: 175
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pedro
--

ALTER SEQUENCE django_content_type_id_seq OWNED BY django_content_type.id;


--
-- TOC entry 174 (class 1259 OID 25391)
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: pedro; Tablespace: 
--

CREATE TABLE django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE django_migrations OWNER TO pedro;

--
-- TOC entry 173 (class 1259 OID 25389)
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: pedro
--

CREATE SEQUENCE django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_migrations_id_seq OWNER TO pedro;

--
-- TOC entry 2256 (class 0 OID 0)
-- Dependencies: 173
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pedro
--

ALTER SEQUENCE django_migrations_id_seq OWNED BY django_migrations.id;


--
-- TOC entry 201 (class 1259 OID 25628)
-- Name: django_session; Type: TABLE; Schema: public; Owner: pedro; Tablespace: 
--

CREATE TABLE django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE django_session OWNER TO pedro;

--
-- TOC entry 194 (class 1259 OID 25563)
-- Name: especialidad_especialidad; Type: TABLE; Schema: public; Owner: pedro; Tablespace: 
--

CREATE TABLE especialidad_especialidad (
    id integer NOT NULL,
    "Nombre" character varying(50) NOT NULL,
    "Codigo" integer NOT NULL
);


ALTER TABLE especialidad_especialidad OWNER TO pedro;

--
-- TOC entry 193 (class 1259 OID 25561)
-- Name: especialidad_especialidad_id_seq; Type: SEQUENCE; Schema: public; Owner: pedro
--

CREATE SEQUENCE especialidad_especialidad_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE especialidad_especialidad_id_seq OWNER TO pedro;

--
-- TOC entry 2257 (class 0 OID 0)
-- Dependencies: 193
-- Name: especialidad_especialidad_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pedro
--

ALTER SEQUENCE especialidad_especialidad_id_seq OWNED BY especialidad_especialidad.id;


--
-- TOC entry 196 (class 1259 OID 25571)
-- Name: profesor_profesor; Type: TABLE; Schema: public; Owner: pedro; Tablespace: 
--

CREATE TABLE profesor_profesor (
    id integer NOT NULL,
    "Nombre" character varying(25) NOT NULL,
    "Apellido" character varying(30) NOT NULL,
    "Edad" integer NOT NULL,
    "Cedula" integer NOT NULL,
    "Titulo" character varying(100) NOT NULL,
    "Anos" integer NOT NULL,
    "Num_tlf" character varying(12) NOT NULL,
    "Correo" character varying(254) NOT NULL,
    "Comentarios" text NOT NULL
);


ALTER TABLE profesor_profesor OWNER TO pedro;

--
-- TOC entry 195 (class 1259 OID 25569)
-- Name: profesor_profesor_id_seq; Type: SEQUENCE; Schema: public; Owner: pedro
--

CREATE SEQUENCE profesor_profesor_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE profesor_profesor_id_seq OWNER TO pedro;

--
-- TOC entry 2258 (class 0 OID 0)
-- Dependencies: 195
-- Name: profesor_profesor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pedro
--

ALTER SEQUENCE profesor_profesor_id_seq OWNED BY profesor_profesor.id;


--
-- TOC entry 205 (class 1259 OID 25661)
-- Name: prueba_estado; Type: TABLE; Schema: public; Owner: pedro; Tablespace: 
--

CREATE TABLE prueba_estado (
    id integer NOT NULL,
    "Nombre" character varying(20),
    "Nombre2" character varying(20)
);


ALTER TABLE prueba_estado OWNER TO pedro;

--
-- TOC entry 204 (class 1259 OID 25659)
-- Name: prueba_estado_id_seq; Type: SEQUENCE; Schema: public; Owner: pedro
--

CREATE SEQUENCE prueba_estado_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE prueba_estado_id_seq OWNER TO pedro;

--
-- TOC entry 2259 (class 0 OID 0)
-- Dependencies: 204
-- Name: prueba_estado_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pedro
--

ALTER SEQUENCE prueba_estado_id_seq OWNED BY prueba_estado.id;


--
-- TOC entry 203 (class 1259 OID 25641)
-- Name: prueba_prueba; Type: TABLE; Schema: public; Owner: pedro; Tablespace: 
--

CREATE TABLE prueba_prueba (
    id integer NOT NULL,
    "Nombre_prueba" character varying(50),
    "Calificacion" integer,
    "Alumno_prueba_id" integer,
    "Curso_prueba_id" integer NOT NULL,
    "Estado_id" integer
);


ALTER TABLE prueba_prueba OWNER TO pedro;

--
-- TOC entry 202 (class 1259 OID 25639)
-- Name: prueba_prueba_id_seq; Type: SEQUENCE; Schema: public; Owner: pedro
--

CREATE SEQUENCE prueba_prueba_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE prueba_prueba_id_seq OWNER TO pedro;

--
-- TOC entry 2260 (class 0 OID 0)
-- Dependencies: 202
-- Name: prueba_prueba_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pedro
--

ALTER SEQUENCE prueba_prueba_id_seq OWNED BY prueba_prueba.id;


--
-- TOC entry 1995 (class 2604 OID 25544)
-- Name: id; Type: DEFAULT; Schema: public; Owner: pedro
--

ALTER TABLE ONLY alumno_alumno ALTER COLUMN id SET DEFAULT nextval('alumno_alumno_id_seq'::regclass);


--
-- TOC entry 1988 (class 2604 OID 25423)
-- Name: id; Type: DEFAULT; Schema: public; Owner: pedro
--

ALTER TABLE ONLY auth_group ALTER COLUMN id SET DEFAULT nextval('auth_group_id_seq'::regclass);


--
-- TOC entry 1989 (class 2604 OID 25433)
-- Name: id; Type: DEFAULT; Schema: public; Owner: pedro
--

ALTER TABLE ONLY auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('auth_group_permissions_id_seq'::regclass);


--
-- TOC entry 1987 (class 2604 OID 25415)
-- Name: id; Type: DEFAULT; Schema: public; Owner: pedro
--

ALTER TABLE ONLY auth_permission ALTER COLUMN id SET DEFAULT nextval('auth_permission_id_seq'::regclass);


--
-- TOC entry 1990 (class 2604 OID 25441)
-- Name: id; Type: DEFAULT; Schema: public; Owner: pedro
--

ALTER TABLE ONLY auth_user ALTER COLUMN id SET DEFAULT nextval('auth_user_id_seq'::regclass);


--
-- TOC entry 1991 (class 2604 OID 25451)
-- Name: id; Type: DEFAULT; Schema: public; Owner: pedro
--

ALTER TABLE ONLY auth_user_groups ALTER COLUMN id SET DEFAULT nextval('auth_user_groups_id_seq'::regclass);


--
-- TOC entry 1992 (class 2604 OID 25459)
-- Name: id; Type: DEFAULT; Schema: public; Owner: pedro
--

ALTER TABLE ONLY auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('auth_user_user_permissions_id_seq'::regclass);


--
-- TOC entry 1998 (class 2604 OID 25585)
-- Name: id; Type: DEFAULT; Schema: public; Owner: pedro
--

ALTER TABLE ONLY curso_curso ALTER COLUMN id SET DEFAULT nextval('curso_cosecha_id_seq'::regclass);


--
-- TOC entry 1999 (class 2604 OID 25609)
-- Name: id; Type: DEFAULT; Schema: public; Owner: pedro
--

ALTER TABLE ONLY "curso_curso_Alumnos_inscritos" ALTER COLUMN id SET DEFAULT nextval('"curso_curso_Alumnos_inscritos_id_seq"'::regclass);


--
-- TOC entry 1993 (class 2604 OID 25519)
-- Name: id; Type: DEFAULT; Schema: public; Owner: pedro
--

ALTER TABLE ONLY django_admin_log ALTER COLUMN id SET DEFAULT nextval('django_admin_log_id_seq'::regclass);


--
-- TOC entry 1986 (class 2604 OID 25405)
-- Name: id; Type: DEFAULT; Schema: public; Owner: pedro
--

ALTER TABLE ONLY django_content_type ALTER COLUMN id SET DEFAULT nextval('django_content_type_id_seq'::regclass);


--
-- TOC entry 1985 (class 2604 OID 25394)
-- Name: id; Type: DEFAULT; Schema: public; Owner: pedro
--

ALTER TABLE ONLY django_migrations ALTER COLUMN id SET DEFAULT nextval('django_migrations_id_seq'::regclass);


--
-- TOC entry 1996 (class 2604 OID 25566)
-- Name: id; Type: DEFAULT; Schema: public; Owner: pedro
--

ALTER TABLE ONLY especialidad_especialidad ALTER COLUMN id SET DEFAULT nextval('especialidad_especialidad_id_seq'::regclass);


--
-- TOC entry 1997 (class 2604 OID 25574)
-- Name: id; Type: DEFAULT; Schema: public; Owner: pedro
--

ALTER TABLE ONLY profesor_profesor ALTER COLUMN id SET DEFAULT nextval('profesor_profesor_id_seq'::regclass);


--
-- TOC entry 2001 (class 2604 OID 25664)
-- Name: id; Type: DEFAULT; Schema: public; Owner: pedro
--

ALTER TABLE ONLY prueba_estado ALTER COLUMN id SET DEFAULT nextval('prueba_estado_id_seq'::regclass);


--
-- TOC entry 2000 (class 2604 OID 25644)
-- Name: id; Type: DEFAULT; Schema: public; Owner: pedro
--

ALTER TABLE ONLY prueba_prueba ALTER COLUMN id SET DEFAULT nextval('prueba_prueba_id_seq'::regclass);


--
-- TOC entry 2223 (class 0 OID 25541)
-- Dependencies: 192
-- Data for Name: alumno_alumno; Type: TABLE DATA; Schema: public; Owner: pedro
--

COPY alumno_alumno (id, "Nombre", "Apellido", "Edad", "Cedula", "Num_tlf", "Correo", "Comentarios") FROM stdin;
1	Pedro	Henriquez	20	25880187	04128445277	tigresmadrid@hotmail.com	
\.


--
-- TOC entry 2261 (class 0 OID 0)
-- Dependencies: 191
-- Name: alumno_alumno_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pedro
--

SELECT pg_catalog.setval('alumno_alumno_id_seq', 1, true);


--
-- TOC entry 2211 (class 0 OID 25420)
-- Dependencies: 180
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: pedro
--

COPY auth_group (id, name) FROM stdin;
\.


--
-- TOC entry 2262 (class 0 OID 0)
-- Dependencies: 179
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pedro
--

SELECT pg_catalog.setval('auth_group_id_seq', 1, false);


--
-- TOC entry 2213 (class 0 OID 25430)
-- Dependencies: 182
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: pedro
--

COPY auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- TOC entry 2263 (class 0 OID 0)
-- Dependencies: 181
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pedro
--

SELECT pg_catalog.setval('auth_group_permissions_id_seq', 1, false);


--
-- TOC entry 2209 (class 0 OID 25412)
-- Dependencies: 178
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: pedro
--

COPY auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can add group	2	add_group
5	Can change group	2	change_group
6	Can delete group	2	delete_group
7	Can add permission	3	add_permission
8	Can change permission	3	change_permission
9	Can delete permission	3	delete_permission
10	Can add user	4	add_user
11	Can change user	4	change_user
12	Can delete user	4	delete_user
13	Can add content type	5	add_contenttype
14	Can change content type	5	change_contenttype
15	Can delete content type	5	delete_contenttype
16	Can add session	6	add_session
17	Can change session	6	change_session
18	Can delete session	6	delete_session
19	Can add alumno	7	add_alumno
20	Can change alumno	7	change_alumno
21	Can delete alumno	7	delete_alumno
22	Can add profesor	8	add_profesor
23	Can change profesor	8	change_profesor
24	Can delete profesor	8	delete_profesor
25	Can add curso	9	add_curso
26	Can change curso	9	change_curso
27	Can delete curso	9	delete_curso
28	Can add especialidad	10	add_especialidad
29	Can change especialidad	10	change_especialidad
30	Can delete especialidad	10	delete_especialidad
31	Can add prueba	11	add_prueba
32	Can change prueba	11	change_prueba
33	Can delete prueba	11	delete_prueba
34	Can add estado	12	add_estado
35	Can change estado	12	change_estado
36	Can delete estado	12	delete_estado
\.


--
-- TOC entry 2264 (class 0 OID 0)
-- Dependencies: 177
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pedro
--

SELECT pg_catalog.setval('auth_permission_id_seq', 36, true);


--
-- TOC entry 2215 (class 0 OID 25438)
-- Dependencies: 184
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: pedro
--

COPY auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
1	pbkdf2_sha256$36000$QD4Ve50sD92n$cCyj45RFQiK+T3gnbZi+iMMv1alWDNXK+FVequ4AITk=	2018-03-05 09:49:25.055318-04	t	pedro			tigresmadrid@hotmail.com	t	t	2018-03-04 20:02:00.47513-04
\.


--
-- TOC entry 2217 (class 0 OID 25448)
-- Dependencies: 186
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: pedro
--

COPY auth_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- TOC entry 2265 (class 0 OID 0)
-- Dependencies: 185
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pedro
--

SELECT pg_catalog.setval('auth_user_groups_id_seq', 1, false);


--
-- TOC entry 2266 (class 0 OID 0)
-- Dependencies: 183
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pedro
--

SELECT pg_catalog.setval('auth_user_id_seq', 1, true);


--
-- TOC entry 2219 (class 0 OID 25456)
-- Dependencies: 188
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: pedro
--

COPY auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- TOC entry 2267 (class 0 OID 0)
-- Dependencies: 187
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pedro
--

SELECT pg_catalog.setval('auth_user_user_permissions_id_seq', 1, false);


--
-- TOC entry 2268 (class 0 OID 0)
-- Dependencies: 197
-- Name: curso_cosecha_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pedro
--

SELECT pg_catalog.setval('curso_cosecha_id_seq', 1, true);


--
-- TOC entry 2229 (class 0 OID 25582)
-- Dependencies: 198
-- Data for Name: curso_curso; Type: TABLE DATA; Schema: public; Owner: pedro
--

COPY curso_curso (id, "Nombre", "Duracion", "Fecha_inicio", "Hora_Comienzo", "Hora_Fin", "Profesor_id", "Especialidad_id", "Codigo") FROM stdin;
1	Python Para Principiantes	6	2018-03-05	13:03:11	18:00:00	1	1	1
\.


--
-- TOC entry 2231 (class 0 OID 25606)
-- Dependencies: 200
-- Data for Name: curso_curso_Alumnos_inscritos; Type: TABLE DATA; Schema: public; Owner: pedro
--

COPY "curso_curso_Alumnos_inscritos" (id, curso_id, alumno_id) FROM stdin;
1	1	1
\.


--
-- TOC entry 2269 (class 0 OID 0)
-- Dependencies: 199
-- Name: curso_curso_Alumnos_inscritos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pedro
--

SELECT pg_catalog.setval('"curso_curso_Alumnos_inscritos_id_seq"', 1, true);


--
-- TOC entry 2221 (class 0 OID 25516)
-- Dependencies: 190
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: pedro
--

COPY django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
1	2018-03-04 20:36:30.393836-04	1	Aprobado	1	[{"added": {}}]	12	1
2	2018-03-04 20:36:41.908572-04	2	Reprobado	1	[{"added": {}}]	12	1
3	2018-03-05 11:50:41.74169-04	1	Heberth Henriquez 9686387	1	[{"added": {}}]	8	1
4	2018-03-05 12:02:39.493172-04	1	Programación	1	[{"added": {}}]	10	1
5	2018-03-05 12:03:40.656516-04	1	Pedro Henriquez 25880187	1	[{"added": {}}]	7	1
6	2018-03-05 12:03:45.357916-04	1	Python Para Principiantes	1	[{"added": {}}]	9	1
7	2018-03-05 12:24:12.541249-04	1	Pedro Henriquez 25880187 Tipos de datos	1	[{"added": {}}]	11	1
\.


--
-- TOC entry 2270 (class 0 OID 0)
-- Dependencies: 189
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pedro
--

SELECT pg_catalog.setval('django_admin_log_id_seq', 7, true);


--
-- TOC entry 2207 (class 0 OID 25402)
-- Dependencies: 176
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: pedro
--

COPY django_content_type (id, app_label, model) FROM stdin;
1	admin	logentry
2	auth	group
3	auth	permission
4	auth	user
5	contenttypes	contenttype
6	sessions	session
7	alumno	alumno
8	profesor	profesor
9	curso	curso
10	especialidad	especialidad
11	prueba	prueba
12	prueba	estado
\.


--
-- TOC entry 2271 (class 0 OID 0)
-- Dependencies: 175
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pedro
--

SELECT pg_catalog.setval('django_content_type_id_seq', 12, true);


--
-- TOC entry 2205 (class 0 OID 25391)
-- Dependencies: 174
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: pedro
--

COPY django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2018-03-04 19:59:58.908878-04
2	auth	0001_initial	2018-03-04 19:59:59.745333-04
3	admin	0001_initial	2018-03-04 19:59:59.935097-04
4	admin	0002_logentry_remove_auto_add	2018-03-04 19:59:59.968041-04
5	alumno	0001_initial	2018-03-04 20:00:00.068424-04
6	alumno	0002_auto_20180301_1716	2018-03-04 20:00:00.089473-04
7	contenttypes	0002_remove_content_type_name	2018-03-04 20:00:00.15677-04
8	auth	0002_alter_permission_name_max_length	2018-03-04 20:00:00.190067-04
9	auth	0003_alter_user_email_max_length	2018-03-04 20:00:00.223276-04
10	auth	0004_alter_user_username_opts	2018-03-04 20:00:00.253012-04
11	auth	0005_alter_user_last_login_null	2018-03-04 20:00:00.279969-04
12	auth	0006_require_contenttypes_0002	2018-03-04 20:00:00.291267-04
13	auth	0007_alter_validators_add_error_messages	2018-03-04 20:00:00.318345-04
14	auth	0008_alter_user_username_max_length	2018-03-04 20:00:00.403543-04
15	especialidad	0001_initial	2018-03-04 20:00:00.471174-04
16	profesor	0001_initial	2018-03-04 20:00:00.570763-04
17	profesor	0002_auto_20180301_1716	2018-03-04 20:00:00.592434-04
18	curso	0001_initial	2018-03-04 20:00:00.704499-04
19	curso	0002_auto_20180301_1716	2018-03-04 20:00:00.760172-04
20	curso	0003_auto_20180301_1720	2018-03-04 20:00:00.792642-04
21	curso	0004_curso_especialidad	2018-03-04 20:00:00.882677-04
22	curso	0005_curso_codigo	2018-03-04 20:00:00.916069-04
23	curso	0006_auto_20180301_1815	2018-03-04 20:00:00.982602-04
24	curso	0007_auto_20180301_1817	2018-03-04 20:00:01.106146-04
25	curso	0008_curso_alumnos_inscritos	2018-03-04 20:00:01.308148-04
26	especialidad	0002_auto_20180301_1815	2018-03-04 20:00:01.372858-04
27	sessions	0001_initial	2018-03-04 20:00:01.550069-04
28	prueba	0001_initial	2018-03-04 20:11:30.123627-04
29	prueba	0002_estado	2018-03-04 20:12:15.766172-04
30	prueba	0003_prueba_estado	2018-03-04 20:13:09.962168-04
31	prueba	0004_auto_20180305_1100	2018-03-05 10:00:32.71165-04
32	especialidad	0003_auto_20180305_1248	2018-03-05 11:49:03.171481-04
33	prueba	0005_auto_20180305_1248	2018-03-05 11:49:03.202204-04
\.


--
-- TOC entry 2272 (class 0 OID 0)
-- Dependencies: 173
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pedro
--

SELECT pg_catalog.setval('django_migrations_id_seq', 33, true);


--
-- TOC entry 2232 (class 0 OID 25628)
-- Dependencies: 201
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: pedro
--

COPY django_session (session_key, session_data, expire_date) FROM stdin;
igehuzsxfuq5dz0vjhxk0paaxqq5dx8q	NTkxZGVhNDY1NWU3ZjFjMDEzM2IyNGYyMzA1ODA4ZTgzNTI0N2UyMTp7Il9hdXRoX3VzZXJfaGFzaCI6ImMzNTgzYmYyNzY2MGI1NWNjMjY3YTU1MjhkZTMwYTBmZTFkZGU0MWUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=	2018-03-19 09:49:25.067209-04
\.


--
-- TOC entry 2225 (class 0 OID 25563)
-- Dependencies: 194
-- Data for Name: especialidad_especialidad; Type: TABLE DATA; Schema: public; Owner: pedro
--

COPY especialidad_especialidad (id, "Nombre", "Codigo") FROM stdin;
1	Programación	1
\.


--
-- TOC entry 2273 (class 0 OID 0)
-- Dependencies: 193
-- Name: especialidad_especialidad_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pedro
--

SELECT pg_catalog.setval('especialidad_especialidad_id_seq', 1, true);


--
-- TOC entry 2227 (class 0 OID 25571)
-- Dependencies: 196
-- Data for Name: profesor_profesor; Type: TABLE DATA; Schema: public; Owner: pedro
--

COPY profesor_profesor (id, "Nombre", "Apellido", "Edad", "Cedula", "Titulo", "Anos", "Num_tlf", "Correo", "Comentarios") FROM stdin;
1	Heberth	Henriquez	42	9686387	Ing. Sistemas	9	04163147610	heberthhenriquez@hotmail.com	
\.


--
-- TOC entry 2274 (class 0 OID 0)
-- Dependencies: 195
-- Name: profesor_profesor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pedro
--

SELECT pg_catalog.setval('profesor_profesor_id_seq', 1, true);


--
-- TOC entry 2236 (class 0 OID 25661)
-- Dependencies: 205
-- Data for Name: prueba_estado; Type: TABLE DATA; Schema: public; Owner: pedro
--

COPY prueba_estado (id, "Nombre", "Nombre2") FROM stdin;
1	Aprobado	Aprobado
2	Reprobado	Reprobado
\.


--
-- TOC entry 2275 (class 0 OID 0)
-- Dependencies: 204
-- Name: prueba_estado_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pedro
--

SELECT pg_catalog.setval('prueba_estado_id_seq', 2, true);


--
-- TOC entry 2234 (class 0 OID 25641)
-- Dependencies: 203
-- Data for Name: prueba_prueba; Type: TABLE DATA; Schema: public; Owner: pedro
--

COPY prueba_prueba (id, "Nombre_prueba", "Calificacion", "Alumno_prueba_id", "Curso_prueba_id", "Estado_id") FROM stdin;
1	Tipos de datos	18	1	1	1
\.


--
-- TOC entry 2276 (class 0 OID 0)
-- Dependencies: 202
-- Name: prueba_prueba_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pedro
--

SELECT pg_catalog.setval('prueba_prueba_id_seq', 1, true);


--
-- TOC entry 2046 (class 2606 OID 25549)
-- Name: alumno_alumno_pkey; Type: CONSTRAINT; Schema: public; Owner: pedro; Tablespace: 
--

ALTER TABLE ONLY alumno_alumno
    ADD CONSTRAINT alumno_alumno_pkey PRIMARY KEY (id);


--
-- TOC entry 2015 (class 2606 OID 25427)
-- Name: auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: pedro; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- TOC entry 2020 (class 2606 OID 25482)
-- Name: auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: pedro; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- TOC entry 2023 (class 2606 OID 25435)
-- Name: auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: pedro; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- TOC entry 2017 (class 2606 OID 25425)
-- Name: auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: pedro; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- TOC entry 2010 (class 2606 OID 25468)
-- Name: auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: pedro; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- TOC entry 2012 (class 2606 OID 25417)
-- Name: auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: pedro; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- TOC entry 2031 (class 2606 OID 25453)
-- Name: auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: pedro; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- TOC entry 2034 (class 2606 OID 25497)
-- Name: auth_user_groups_user_id_group_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: pedro; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- TOC entry 2025 (class 2606 OID 25443)
-- Name: auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: pedro; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- TOC entry 2037 (class 2606 OID 25461)
-- Name: auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: pedro; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- TOC entry 2040 (class 2606 OID 25511)
-- Name: auth_user_user_permissions_user_id_permission_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: pedro; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- TOC entry 2028 (class 2606 OID 25551)
-- Name: auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: pedro; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- TOC entry 2058 (class 2606 OID 25587)
-- Name: curso_cosecha_pkey; Type: CONSTRAINT; Schema: public; Owner: pedro; Tablespace: 
--

ALTER TABLE ONLY curso_curso
    ADD CONSTRAINT curso_cosecha_pkey PRIMARY KEY (id);


--
-- TOC entry 2065 (class 2606 OID 25623)
-- Name: curso_curso_Alumnos_inscritos_curso_id_alumno_id_3dbd325a_uniq; Type: CONSTRAINT; Schema: public; Owner: pedro; Tablespace: 
--

ALTER TABLE ONLY "curso_curso_Alumnos_inscritos"
    ADD CONSTRAINT "curso_curso_Alumnos_inscritos_curso_id_alumno_id_3dbd325a_uniq" UNIQUE (curso_id, alumno_id);


--
-- TOC entry 2067 (class 2606 OID 25611)
-- Name: curso_curso_Alumnos_inscritos_pkey; Type: CONSTRAINT; Schema: public; Owner: pedro; Tablespace: 
--

ALTER TABLE ONLY "curso_curso_Alumnos_inscritos"
    ADD CONSTRAINT "curso_curso_Alumnos_inscritos_pkey" PRIMARY KEY (id);


--
-- TOC entry 2060 (class 2606 OID 25603)
-- Name: curso_curso_Codigo_c2884c03_uniq; Type: CONSTRAINT; Schema: public; Owner: pedro; Tablespace: 
--

ALTER TABLE ONLY curso_curso
    ADD CONSTRAINT "curso_curso_Codigo_c2884c03_uniq" UNIQUE ("Codigo");


--
-- TOC entry 2043 (class 2606 OID 25525)
-- Name: django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: pedro; Tablespace: 
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- TOC entry 2005 (class 2606 OID 25409)
-- Name: django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: pedro; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- TOC entry 2007 (class 2606 OID 25407)
-- Name: django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: pedro; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- TOC entry 2003 (class 2606 OID 25399)
-- Name: django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: pedro; Tablespace: 
--

ALTER TABLE ONLY django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- TOC entry 2070 (class 2606 OID 25635)
-- Name: django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: pedro; Tablespace: 
--

ALTER TABLE ONLY django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- TOC entry 2048 (class 2606 OID 25627)
-- Name: especialidad_especialidad_Codigo_050c85d3_uniq; Type: CONSTRAINT; Schema: public; Owner: pedro; Tablespace: 
--

ALTER TABLE ONLY especialidad_especialidad
    ADD CONSTRAINT "especialidad_especialidad_Codigo_050c85d3_uniq" UNIQUE ("Codigo");


--
-- TOC entry 2051 (class 2606 OID 25674)
-- Name: especialidad_especialidad_Nombre_48b27bfc_uniq; Type: CONSTRAINT; Schema: public; Owner: pedro; Tablespace: 
--

ALTER TABLE ONLY especialidad_especialidad
    ADD CONSTRAINT "especialidad_especialidad_Nombre_48b27bfc_uniq" UNIQUE ("Nombre");


--
-- TOC entry 2053 (class 2606 OID 25568)
-- Name: especialidad_especialidad_pkey; Type: CONSTRAINT; Schema: public; Owner: pedro; Tablespace: 
--

ALTER TABLE ONLY especialidad_especialidad
    ADD CONSTRAINT especialidad_especialidad_pkey PRIMARY KEY (id);


--
-- TOC entry 2055 (class 2606 OID 25579)
-- Name: profesor_profesor_pkey; Type: CONSTRAINT; Schema: public; Owner: pedro; Tablespace: 
--

ALTER TABLE ONLY profesor_profesor
    ADD CONSTRAINT profesor_profesor_pkey PRIMARY KEY (id);


--
-- TOC entry 2078 (class 2606 OID 25666)
-- Name: prueba_estado_pkey; Type: CONSTRAINT; Schema: public; Owner: pedro; Tablespace: 
--

ALTER TABLE ONLY prueba_estado
    ADD CONSTRAINT prueba_estado_pkey PRIMARY KEY (id);


--
-- TOC entry 2076 (class 2606 OID 25646)
-- Name: prueba_prueba_pkey; Type: CONSTRAINT; Schema: public; Owner: pedro; Tablespace: 
--

ALTER TABLE ONLY prueba_prueba
    ADD CONSTRAINT prueba_prueba_pkey PRIMARY KEY (id);


--
-- TOC entry 2013 (class 1259 OID 25470)
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: pedro; Tablespace: 
--

CREATE INDEX auth_group_name_a6ea08ec_like ON auth_group USING btree (name varchar_pattern_ops);


--
-- TOC entry 2018 (class 1259 OID 25483)
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: pedro; Tablespace: 
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON auth_group_permissions USING btree (group_id);


--
-- TOC entry 2021 (class 1259 OID 25484)
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: pedro; Tablespace: 
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON auth_group_permissions USING btree (permission_id);


--
-- TOC entry 2008 (class 1259 OID 25469)
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: pedro; Tablespace: 
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON auth_permission USING btree (content_type_id);


--
-- TOC entry 2029 (class 1259 OID 25499)
-- Name: auth_user_groups_group_id_97559544; Type: INDEX; Schema: public; Owner: pedro; Tablespace: 
--

CREATE INDEX auth_user_groups_group_id_97559544 ON auth_user_groups USING btree (group_id);


--
-- TOC entry 2032 (class 1259 OID 25498)
-- Name: auth_user_groups_user_id_6a12ed8b; Type: INDEX; Schema: public; Owner: pedro; Tablespace: 
--

CREATE INDEX auth_user_groups_user_id_6a12ed8b ON auth_user_groups USING btree (user_id);


--
-- TOC entry 2035 (class 1259 OID 25513)
-- Name: auth_user_user_permissions_permission_id_1fbb5f2c; Type: INDEX; Schema: public; Owner: pedro; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_permission_id_1fbb5f2c ON auth_user_user_permissions USING btree (permission_id);


--
-- TOC entry 2038 (class 1259 OID 25512)
-- Name: auth_user_user_permissions_user_id_a95ead1b; Type: INDEX; Schema: public; Owner: pedro; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_user_id_a95ead1b ON auth_user_user_permissions USING btree (user_id);


--
-- TOC entry 2026 (class 1259 OID 25552)
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: pedro; Tablespace: 
--

CREATE INDEX auth_user_username_6821ab7c_like ON auth_user USING btree (username varchar_pattern_ops);


--
-- TOC entry 2056 (class 1259 OID 25593)
-- Name: curso_cosecha_Profesor_id_f16b8f47; Type: INDEX; Schema: public; Owner: pedro; Tablespace: 
--

CREATE INDEX "curso_cosecha_Profesor_id_f16b8f47" ON curso_curso USING btree ("Profesor_id");


--
-- TOC entry 2062 (class 1259 OID 25625)
-- Name: curso_curso_Alumnos_inscritos_alumno_id_be752234; Type: INDEX; Schema: public; Owner: pedro; Tablespace: 
--

CREATE INDEX "curso_curso_Alumnos_inscritos_alumno_id_be752234" ON "curso_curso_Alumnos_inscritos" USING btree (alumno_id);


--
-- TOC entry 2063 (class 1259 OID 25624)
-- Name: curso_curso_Alumnos_inscritos_curso_id_97849f21; Type: INDEX; Schema: public; Owner: pedro; Tablespace: 
--

CREATE INDEX "curso_curso_Alumnos_inscritos_curso_id_97849f21" ON "curso_curso_Alumnos_inscritos" USING btree (curso_id);


--
-- TOC entry 2061 (class 1259 OID 25594)
-- Name: curso_curso_Especialidad_id_e4cebfa7; Type: INDEX; Schema: public; Owner: pedro; Tablespace: 
--

CREATE INDEX "curso_curso_Especialidad_id_e4cebfa7" ON curso_curso USING btree ("Especialidad_id");


--
-- TOC entry 2041 (class 1259 OID 25536)
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: pedro; Tablespace: 
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON django_admin_log USING btree (content_type_id);


--
-- TOC entry 2044 (class 1259 OID 25537)
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: pedro; Tablespace: 
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON django_admin_log USING btree (user_id);


--
-- TOC entry 2068 (class 1259 OID 25637)
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: pedro; Tablespace: 
--

CREATE INDEX django_session_expire_date_a5c62663 ON django_session USING btree (expire_date);


--
-- TOC entry 2071 (class 1259 OID 25636)
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: pedro; Tablespace: 
--

CREATE INDEX django_session_session_key_c0390e0f_like ON django_session USING btree (session_key varchar_pattern_ops);


--
-- TOC entry 2049 (class 1259 OID 25675)
-- Name: especialidad_especialidad_Nombre_48b27bfc_like; Type: INDEX; Schema: public; Owner: pedro; Tablespace: 
--

CREATE INDEX "especialidad_especialidad_Nombre_48b27bfc_like" ON especialidad_especialidad USING btree ("Nombre" varchar_pattern_ops);


--
-- TOC entry 2072 (class 1259 OID 25657)
-- Name: prueba_prueba_Alumno_prueba_id_0c8bbbea; Type: INDEX; Schema: public; Owner: pedro; Tablespace: 
--

CREATE INDEX "prueba_prueba_Alumno_prueba_id_0c8bbbea" ON prueba_prueba USING btree ("Alumno_prueba_id");


--
-- TOC entry 2073 (class 1259 OID 25658)
-- Name: prueba_prueba_Curso_prueba_id_5ecd9027; Type: INDEX; Schema: public; Owner: pedro; Tablespace: 
--

CREATE INDEX "prueba_prueba_Curso_prueba_id_5ecd9027" ON prueba_prueba USING btree ("Curso_prueba_id");


--
-- TOC entry 2074 (class 1259 OID 25667)
-- Name: prueba_prueba_Estado_id_6e494f35; Type: INDEX; Schema: public; Owner: pedro; Tablespace: 
--

CREATE INDEX "prueba_prueba_Estado_id_6e494f35" ON prueba_prueba USING btree ("Estado_id");


--
-- TOC entry 2081 (class 2606 OID 25476)
-- Name: auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: pedro
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 2080 (class 2606 OID 25471)
-- Name: auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: pedro
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 2079 (class 2606 OID 25462)
-- Name: auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: pedro
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 2083 (class 2606 OID 25491)
-- Name: auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: pedro
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 2082 (class 2606 OID 25486)
-- Name: auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: pedro
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 2085 (class 2606 OID 25505)
-- Name: auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: pedro
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 2084 (class 2606 OID 25500)
-- Name: auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: pedro
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 2088 (class 2606 OID 25588)
-- Name: curso_cosecha_Profesor_id_f16b8f47_fk_profesor_profesor_id; Type: FK CONSTRAINT; Schema: public; Owner: pedro
--

ALTER TABLE ONLY curso_curso
    ADD CONSTRAINT "curso_cosecha_Profesor_id_f16b8f47_fk_profesor_profesor_id" FOREIGN KEY ("Profesor_id") REFERENCES profesor_profesor(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 2091 (class 2606 OID 25617)
-- Name: curso_curso_Alumnos__alumno_id_be752234_fk_alumno_al; Type: FK CONSTRAINT; Schema: public; Owner: pedro
--

ALTER TABLE ONLY "curso_curso_Alumnos_inscritos"
    ADD CONSTRAINT "curso_curso_Alumnos__alumno_id_be752234_fk_alumno_al" FOREIGN KEY (alumno_id) REFERENCES alumno_alumno(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 2090 (class 2606 OID 25612)
-- Name: curso_curso_Alumnos__curso_id_97849f21_fk_curso_cur; Type: FK CONSTRAINT; Schema: public; Owner: pedro
--

ALTER TABLE ONLY "curso_curso_Alumnos_inscritos"
    ADD CONSTRAINT "curso_curso_Alumnos__curso_id_97849f21_fk_curso_cur" FOREIGN KEY (curso_id) REFERENCES curso_curso(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 2089 (class 2606 OID 25595)
-- Name: curso_curso_Especialidad_id_e4cebfa7_fk_especiali; Type: FK CONSTRAINT; Schema: public; Owner: pedro
--

ALTER TABLE ONLY curso_curso
    ADD CONSTRAINT "curso_curso_Especialidad_id_e4cebfa7_fk_especiali" FOREIGN KEY ("Especialidad_id") REFERENCES especialidad_especialidad(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 2086 (class 2606 OID 25526)
-- Name: django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: pedro
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 2087 (class 2606 OID 25556)
-- Name: django_admin_log_user_id_c564eba6_fk; Type: FK CONSTRAINT; Schema: public; Owner: pedro
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 2092 (class 2606 OID 25647)
-- Name: prueba_prueba_Alumno_prueba_id_0c8bbbea_fk_alumno_alumno_id; Type: FK CONSTRAINT; Schema: public; Owner: pedro
--

ALTER TABLE ONLY prueba_prueba
    ADD CONSTRAINT "prueba_prueba_Alumno_prueba_id_0c8bbbea_fk_alumno_alumno_id" FOREIGN KEY ("Alumno_prueba_id") REFERENCES alumno_alumno(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 2093 (class 2606 OID 25652)
-- Name: prueba_prueba_Curso_prueba_id_5ecd9027_fk_curso_curso_id; Type: FK CONSTRAINT; Schema: public; Owner: pedro
--

ALTER TABLE ONLY prueba_prueba
    ADD CONSTRAINT "prueba_prueba_Curso_prueba_id_5ecd9027_fk_curso_curso_id" FOREIGN KEY ("Curso_prueba_id") REFERENCES curso_curso(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 2094 (class 2606 OID 25668)
-- Name: prueba_prueba_Estado_id_6e494f35_fk_prueba_estado_id; Type: FK CONSTRAINT; Schema: public; Owner: pedro
--

ALTER TABLE ONLY prueba_prueba
    ADD CONSTRAINT "prueba_prueba_Estado_id_6e494f35_fk_prueba_estado_id" FOREIGN KEY ("Estado_id") REFERENCES prueba_estado(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 2243 (class 0 OID 0)
-- Dependencies: 6
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


-- Completed on 2018-03-05 13:15:42 VET

--
-- PostgreSQL database dump complete
--


from django.shortcuts import render_to_response
from django.shortcuts import render
from profesor.models import Profesor
from alumno.models import Alumno
from especialidad.models import Especialidad
from curso.models import Curso
from prueba.models import Prueba
def home(request):
    return render_to_response('home.html')

def add(request):
    return render_to_response('add.html')

def query(request):
    return render_to_response('query.html')

def profesores(request): 
    return render(request, 'prof.html', {'profesores': Profesor.objects.all()})

def alumnos(request): 
    return render(request, 'alum.html', {'alumnos': Alumno.objects.all()})

def especialidades(request): 
    return render(request, 'espe.html', {'especialidades': Especialidad.objects.all()})

def cursos(request): 
    return render(request, 'cur.html', {'cursos': Curso.objects.all()})

def pruebas(request): 
    return render(request, 'test.html', {'pruebas': Prueba.objects.all()})
